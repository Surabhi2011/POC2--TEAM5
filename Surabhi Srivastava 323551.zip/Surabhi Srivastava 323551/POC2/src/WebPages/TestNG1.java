package WebPages;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.BeforeClass;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class TestNG1 {
	WebDriver dr;
	Login login;
	HomePage homepage;
	MyAccount account;
	Logger log;
	WebDriverWait wt;
	@BeforeClass
	public void Launch() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		log=Logger.getLogger("devpinoyLogger");
		log.info("Browser launched");
	}

	@Test(priority=1)
	public void testhomepagetitle() {
		wt = new WebDriverWait(dr, 10);
		homepage = new HomePage(dr);
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")));
		String actual = homepage.get_title();
		String expected = "Demo Web Shop";
		SoftAssert s=new SoftAssert();
		s.assertEquals(actual, expected);
		//log=Logger.getLogger("devpinoyLogger");
		log.info("==========================================================================================================");
		log.info("Test Case _ Verify HomePage title ");
		log.info("==========================================================================================================");
		log.info("Expected : "+expected);
		log.info("Actual : "+actual);
		log.info("Test Result : Pass");

	}
	@Test(priority=2)
	public void testhomepageRegister() {
		homepage = new HomePage(dr);
		String actual = homepage.get_register();
		String expected = "Register";
		SoftAssert s=new SoftAssert();
		s.assertEquals(actual, expected);
		//log=Logger.getLogger("devpinoyLogger");
		log.info("==========================================================================================================");
		log.info("Test Case _ Verify Register Text on HomePage ");
		log.info("==========================================================================================================");
		log.info("Expected : "+expected);
		log.info("Actual : "+actual);
		log.info("Test Result : Pass");

	}
	@Test(priority=3)
	public void testhomepagelogin() {
		homepage = new HomePage(dr);
		String actual = homepage.get_Login();
		String expected = "Log in";
		SoftAssert s=new SoftAssert();
		s.assertEquals(actual, expected);
		//log=Logger.getLogger("devpinoyLogger");
		log.info("==========================================================================================================");
		log.info("Test Case _ Verify Login Text on HomePage");
		log.info("==========================================================================================================");
		log.info("Expected : "+expected);
		log.info("Actual : "+actual);
		log.info("Test Result : Pass");

	}
	
}
