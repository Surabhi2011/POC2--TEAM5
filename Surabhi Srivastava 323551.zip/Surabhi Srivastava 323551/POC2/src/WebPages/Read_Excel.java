package WebPages;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Read_Excel {
	private XSSFWorkbook wb;

	public String[][] read() {
		String[][] arr = new String[2][3];
	try {
		
		File f = new File("C:\\Users\\surabhi.srivastava\\Desktop\\SeleniumExcel.xlsx");
		FileInputStream fis = new FileInputStream(f);
		wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		for (int i = 0; i <= 1; i++) {
			
			XSSFRow row = sh.getRow(i+1);
			arr[i][0] = row.getCell(0).getStringCellValue();
		    arr[i][1]= row.getCell(1).getStringCellValue();
			arr[i][2]= row.getCell(2).getStringCellValue();
			
		}
	} catch (Exception e) {
    }
	return arr;
}
	
}